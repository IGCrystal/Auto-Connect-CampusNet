from setuptools import setup

setup(
    name='Auto-Connect-CampusNet',
    version='1.0',
    packages=[''],
    install_requires=[
        "requests",
    ],
    url='',
    license='GNU Affero General Public License v3.0',
    author='IGCrystal',
    author_email='2749332490@qq.com',
    description='校园网连接脚本，配合计划任务效果更好！但主要还是自己用，放在GitHub主要是为了多端安装。'
)
